function [label] = mlrPredict(W, X)
% blrObjFunction predicts the label of data given the data and parameter W
% of multi-class Logistic Regression
%
% Input:
% W: the matrix of weight of size (D + 1) x 10
% X: the data matrix of size N x D
%
% Output: 
% label: vector of size N x 1 representing the predicted label of
%        corresponding feature vector given in data matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%label = zeros(size(X, 1), 1); % dummy return

N=size(X,1);
D=size(X,2);
bias = ones(N,1);
X = [bias X]; % N x D+1
K = 10;
Ank = X*W; % N x k

temp = logsumexp(Ank,2); % N x 1

logsumAk = zeros(size(Ank));


for i=1:N
    logsumAk(i,:)=temp(i,1);
end

LnYnk = Ank - logsumAk; % N x k
size(LnYnk)


Ynk = exp(LnYnk);


label = getLabel(Ynk);

end

