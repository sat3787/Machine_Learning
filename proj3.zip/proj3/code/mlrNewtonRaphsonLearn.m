function [W] = mlrNewtonRaphsonLearn(initial_W, X, T, n_iter)
%mlrNewtonRaphsonLearn learns the weight vector of multi-class Logistic
%Regresion using Newton-Raphson method
% Input:
% initial_W: matrix of size (D+1) x 10 represents the initial weight matrix 
%            for iterative method
% X: matrix of feature vector which size is N x D where N is number of
%            samples and D is number of feature in a feature vector
% T: the label matrix of size N x 10 where each row represent the one-of-K
%    encoding of the true label of corresponding feature vector
% n_inter: maximum number of iterations in Newton Raphson method
%
% Output:
% W: matrix of size (D+1) x 10, represented the learned weight obatained by
%    using Newton-Raphson method

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%W = zeros(size(X, 2) + 1, 10); % dummy return

W = reshape(initial_W, size(X, 2) + 1, size(T, 2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% error = 0; % dummy return
% error_grad = zeros((size(X, 2) + 1) * 10, 1); % dummy return
N=size(X,1);
D=size(X,2);
bias = ones(N,1);
X = [bias X]; % N x D+1
K = 10;

% Yn = sigmoid(X*W); % N x 1
% 
% Rnn = diag(Yn); % N x N
% 
% Hinv = X' * Rnn * X;  % D+1 x D+1



Wold = W


% for i=1:n_iter
%     fprintf('\nIteration %d',i);
%     Ank = X*Wold; % N x k
% 
%     temp = logsumexp(Ank,2); % N x 1
% 
%     logsumAk = zeros(size(Ank));
% 
% 
%     for j=1:N
%         logsumAk(i,:)=temp(i,1);
%     end
% 
%     LnYnk = Ank - logsumAk; % N x k
%    
%     Ynk = exp(LnYnk); % Nx K
% 
%     Rnn = Ynk * (ones(size(Ynk)) - Ynk)'; % N x N
% 
% 
%     Hinv = pinv(X' * Rnn * X) ;
%     Wnew = Wold - Hinv* X' * (Ynk - T);
%     Wold = Wnew;
%     
% end
%     W=Wnew;
%#######################################
for k = 1:K
    
    %fprintf('\nIteration %d',i);
    fprintf('\n Class %d',k);
    for i = 1:n_iter
        %equation
        
        Hinv = pinv(X'*X); %D+1xD+1
        grad_error = X'*X*Wold - X'*T;
        Wnew = Wold - Hinv*grad_error;
        Wold = Wnew;
        
        
    end
end
%######################################
% for k = 1:K
%     
%     %fprintf('\nIteration %d',i);
%     fprintf('\n Class %d',k);
%     for i = 1:n_iter
%         %equation
%         Ank = X*Wold; % N x k
%         
%         temp = logsumexp(Ank,2); % N x 1
%         
%         logsumAk = zeros(size(Ank));
%         
%         
%         for j=1:N
%             logsumAk(i,:)=temp(i,1);
%         end
%         
%         LnYnk = Ank - logsumAk; % N x k
%         
%         Ynk = exp(LnYnk); % Nx K
%         
%         Rnn = Ynk * (ones(size(Ynk)) - Ynk)';
%         Hinv = pinv(X'*Rnn*X); %D+1xD+1
%         grad_error = X'*X*Wold - X'*T;
%         Wnew = Wold - Hinv*grad_error;
%         Wold = Wnew;
%         
%         
%     end
% end



W = Wnew;




end

