function labels = getLabel(data)
labelstmp=[];
size(data)
for i=1:size(data,1)
    
datamax=max(data(i,:));
labelstmp(i,1)=find(data(i,:)==datamax);

end
labels=labelstmp;
end
