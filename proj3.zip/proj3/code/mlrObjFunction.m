function [error, error_grad] = mlrObjFunction(W, X, T)
% mlrObjFunction computes multi-class Logistic Regression error function 
% and its gradient.
%
% Input:
% W: the vector of size ((D + 1) * 10) x 1. Later on, it will reshape into
%    matrix of size D + 1) x 10
% X: the data matrix of size N x D
% T: the label matrix of size N x 10 where each row represent the one-of-K
%    encoding of the true label of corresponding feature vector
%
% Output: 
% error: the scalar value of error function of 2-class logistic regression
% error_grad: the vector of size ((D+1) * 10) x 1 representing the gradient 
%             of error function


W = reshape(W, size(X, 2) + 1, size(T, 2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% error = 0; % dummy return
% error_grad = zeros((size(X, 2) + 1) * 10, 1); % dummy return
N=size(X,1);
D=size(X,2);
bias = ones(N,1);
X = [bias X]; % N x D+1
K = 10;
Ank = X*W; % N x k

temp = logsumexp(Ank,2); % N x 1

logsumAk = zeros(size(Ank));


for i=1:N
    logsumAk(i,:)=temp(i,1);
end

LnYnk = Ank - logsumAk; % N x k
size(LnYnk)

% wrong! LnYnk = Ank - logsumexp(Ank,2); 


error =0;

for i = 1:N
    for j = 1:K
        error = error + T(i,j)*LnYnk(i,j);
    end
end

error = error * -1



% error = -1 * sum(sum((T .* LnYnk)));
% 
Ynk = exp(LnYnk);

error_grad = X' * (Ynk - T);
%size(error_grad)

error_grad = reshape(error_grad, (D+1)*10,1);
size(error_grad)






end
