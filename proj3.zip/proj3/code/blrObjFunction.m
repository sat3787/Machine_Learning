function [error, error_grad] = blrObjFunction(w, X, t)
% blrObjFunction computes 2-class Logistic Regression error function and
% its gradient.
%
% Input:
% w: the weight vector of size (D + 1) x 1 
% X: the data matrix of size N x D
% t: the label vector of size N x 1 where each entry can be either 0 or 1
%    representing the label of corresponding feature vector
%
% Output: 
% error: the scalar value of error function of 2-class logistic regression
% error_grad: the vector of size (D+1) x 1 representing the gradient of
%             error function


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
error = 0; % dummy return
error_grad = zeros(size(X, 2) + 1, 1); % dummy return

N=size(X,1);
D=size(X,2);
bias = ones(N,1);

X = [bias X]; % N x D+1

Yn = sigmoid(X*w); % N x 1

p1 = t'*log(Yn);

p2 = (bias - t)' * log(bias - Yn);

error = -(p1+p2);

error_grad = X'*(Yn-t) % D+1 x 1



end
