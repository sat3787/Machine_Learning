function [train_data, train_label, validation_data, ...
    validation_label, test_data, test_label] = preprocess()
% preprocess function loads the original data set, performs some preprocess
%   tasks, and output the preprocessed train, validation and test data.

% Input:
% Although this function doesn't have any input, you are required to load
% the MNIST data set from file 'mnist_all.mat'.

% Output:
% train_data: matrix of training set. Each row of train_data contains
%   feature vector of a image
% train_label: vector of label corresponding to each image in the training
%   set
% validation_data: matrix of training set. Each row of validation_data
%   contains feature vector of a image
% validation_label: vector of label corresponding to each image in the
%   training set
% test_data: matrix of testing set. Each row of test_data contains
%   feature vector of a image
% test_label: vector of label corresponding to each image in the testing
%   set

% Some suggestions for preprocessing step:
% - divide the original data set to training, validation and testing set
%       with corresponding labels
% - convert original data set from integer to double by using double()
%       function
% - normalize the data to [0, 1]
% - feature selection

load('mnist_all.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
labeltrain0(1:size(train0,1))=deal(0);
labeltrain1(1:size(train1,1))=deal(1);
labeltrain2(1:size(train2,1))=deal(2);
labeltrain3(1:size(train3,1))=deal(3);
labeltrain4(1:size(train4,1))=deal(4);
labeltrain5(1:size(train5,1))=deal(5);
labeltrain6(1:size(train6,1))=deal(6);
labeltrain7(1:size(train7,1))=deal(7);
labeltrain8(1:size(train8,1))=deal(8);
labeltrain9(1:size(train9,1))=deal(9);
labeltest0(1:size(test0,1))=deal(0);
labeltest1(1:size(test1,1))=deal(1);
labeltest2(1:size(test2,1))=deal(2);
labeltest3(1:size(test3,1))=deal(3);
labeltest4(1:size(test4,1))=deal(4);
labeltest5(1:size(test5,1))=deal(5);
labeltest6(1:size(test6,1))=deal(6);
labeltest7(1:size(test7,1))=deal(7);
labeltest8(1:size(test8,1))=deal(8);
labeltest9(1:size(test9,1))=deal(9);

%training data processing
train_label=[labeltrain0';labeltrain1';labeltrain2';labeltrain3';labeltrain4';labeltrain5';labeltrain6';labeltrain7';labeltrain8';labeltrain9'];
train_data=[train0;train1;train2;train3;train4;train5;train6;train7;train8;train9];
sum_train=sum(train_data,1);

%test data processing
test_label=[labeltest0';labeltest1';labeltest2';labeltest3';labeltest4';labeltest5';labeltest6';labeltest7';labeltest8';labeltest9'];
test_data=[test0;test1;test2;test3;test4;test5;test6;test7;test8;test9];


%calculations
tmp_matrix=[];
tmp_tmatrix=[];
for i=1:size(sum_train,2)
    if sum_train(1,i)~=0
        tmp_matrix=horzcat(tmp_matrix,train_data(:,i));
        tmp_tmatrix=horzcat(tmp_tmatrix,test_data(:,i));
    end
end
train_data=tmp_matrix;
test_data=tmp_tmatrix;
tmp_matrix=[];

train_data = double(train_data) ./ 255;
test_data = double(test_data) ./ 255;
train_data=horzcat(train_data,train_label);
test_data=horzcat(test_data,test_label);
shuffledArray1 = train_data(randperm(size(train_data,1)),:);
train_data=shuffledArray1(1:50000,1:size(shuffledArray1,2)-1);
train_label=shuffledArray1(1:50000,size(shuffledArray1,2));
validation_data=shuffledArray1(50001:60000,1:size(shuffledArray1,2)-1);
validation_label=shuffledArray1(50001:60000,size(shuffledArray1,2));
shuffledArray2 = test_data(randperm(size(test_data,1)),:);
test_data=shuffledArray2(1:end,1:size(shuffledArray2,2)-1);
test_label=shuffledArray2(1:end,size(shuffledArray2,2));

%%%%%%%%%%%%%%%
train_data=train_data(1:1000,:);
%Tg=size(train_data)
train_label=train_label(1:1000,:);
%Tg_Lbl=size(train_label)
validation_data=validation_data(1:500,:);
%Val=size(validation_data)
validation_label=validation_label(1:500,:);
%Val_Lbl=size(validation_label)
test_data=test_data(1:500,:);
%T_data=size(test_data)
test_label=test_label(1:500,:);
%T_label=size(test_label)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
            
