function labels = getLabel(data)
labelstmp=zeros(max(size(data)),1);
for i=1:size(data,1)
    
datamax=max(data(i,:));
labelstmp(i,1)=find(data(i,:)==datamax)-1;

end
labels=labelstmp;
end