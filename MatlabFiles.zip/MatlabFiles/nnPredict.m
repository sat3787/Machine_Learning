function label = nnPredict(w1, w2, data)
% nnPredict predicts the label of data given the parameter w1, w2 of Neural
% Network.

% Input:
% w1: matrix of weights of connections from input layer to hidden layers.
%     w1(i, j) represents the weight of connection from unit j in input 
%     layer to unit j in hidden layer.
% w2: matrix of weights of connections from hidden layer to output layers.
%     w2(i, j) represents the weight of connection from unit j in input 
%     layer to unit j in hidden layer.
% data: matrix of data. Each row of this matrix represents the feature 
%       vector of a particular image
       
% Output: 
% label: a column vector of predicted labels

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   YOUR CODE HERE %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% data is represented by m X n
% w1 is represented by j X n
% w2 is representedd by k X j
bias=ones(size(data,1),1);
data=[data bias];
data=data';
aj=w1*data;
zj=sigmoid(aj); %ex. size = n_hidden,50000

%add the a matrix of ones to add bias to the input
bias=ones(1,size(zj,2));
zj=[zj;bias]; %ex. size = n_hidden+1,50000

bk=w2*zj;
yk=sigmoid((bk'));
label=getLabel(yk); %ex. size n_class, 50000=10,50000'
end
