function tn = tnpopulate(label,n_class)
tn=zeros(size(label,1),n_class);
for i=1:size(label,1)
    tn(i,(label(i,1)+1))=1;
end


end