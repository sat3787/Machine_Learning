function [error, error_grad] = regressionObjVal(w,X,y,lambda)
% compute squared error (scalar) and gradient of squared error with respect
% to w (vector) for the given data X and y and the regularization parameter
% lambda
	I_D=eye(size(X,2));
	N=size(X,1);
	error=(1/N)*((y-X*w)')*(y-X*w)+lambda*((w')*w);
	error_grad=(2/N)*(((X')*X)*w-(X')*y)+2*lambda*w;
end
