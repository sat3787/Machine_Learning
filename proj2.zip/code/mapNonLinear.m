function x_n = mapNonLinear(x,d)
% Inputs:
% x - a single column vector (N x 1)
% d - integer (>= 0)
% Outputs:
% x_n - (N x (d+1))
x_n=[];
	for i=0:d
		temp=x.^i;
		x_n=[x_n temp];
	end
end
