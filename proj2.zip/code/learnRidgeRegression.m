function w = learnRidgeRegression(X,y,lambda)

% Implement ridge regression training here
% Inputs:
% X = N x D
% y = N x 1
% lambda = scalar
% Output:
% w = D x 1
I_D=eye(size(X,2));
N=size(X,1);
w=pinv((X')*X+N*lambda*I_D)*(X')*y;
end
