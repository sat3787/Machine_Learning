% load the data
load diabetes;
x_train_i = [ones(size(x_train,1),1) x_train];
x_test_i = [ones(size(x_test,1),1) x_test];
%%% FILL CODE FOR PROBLEM 1 %%%
% linear regression without intercept
display('OLE method without intercept');
error_train = 0;
error_test = 0;
w=learnOLERegression(x_train,y_train);
error_train=(((y_train-(x_train*w))')*(y_train-(x_train*w)))^(0.5)
error_test=(((y_test-(x_test*w))')*(y_test-(x_test*w)))^(0.5)
% linear regression with intercept
display('OLE method with intercept');
error_train_i = 0;
error_test_i = 0;
w_i=learnOLERegression(x_train_i,y_train);
error_train_i=(((y_train-(x_train_i*w_i))')*(y_train-(x_train_i*w_i)))^(0.5)
error_test_i=(((y_test-(x_test_i*w_i))')*(y_test-(x_test_i*w_i)))^(0.5)

% figure;
% x=1:size(y_train,1);
% y_train=size(y_train)
% xtrain=size(x_train)
% scatter(x_train, y_train);
% hold on;
% plot(x_train_i,(x_train_i*w_i));
% hold off;



%pause;
%%% END PROBLEM 1 CODE %%%

%%% FILL CODE FOR PROBLEM 2 %%%
% ridge regression using least squares - minimization
lambdas = 0:0.00001:0.001;
train_errors = zeros(length(lambdas),1);
test_errors = zeros(length(lambdas),1);


for i = 1:length(lambdas)
    lambda = lambdas(i);
    
        
    % fill code here for prediction and computing errors
    w_ridge=learnRidgeRegression(x_train_i,y_train,lambda);
    y_predicted_test=x_test_i*w_ridge;
    train_errors(i,1)=(((y_train-(x_train_i*w_ridge))')*(y_train-(x_train_i*w_ridge)))^(0.5);
    test_errors(i,1)=(((y_test-(y_predicted_test))')*(y_test-(y_predicted_test)))^(0.5);
%     if(errormin==0)
%         errormin=test_errors(i,1);
%         
%     end
%     if(errormin>test_error(i,1))
%         errormin=test_error(i,1);
%         lambdamin=lambda;
%     end

% figure;
% x=1:size(y_train,1);
% size(y_train,1)
% size(y_predicted_test)
% scatter(x, y_train);
% hold on;
% plot(x,y_predicted_test);
% hold off;

    
    
end
figure;

%plot([train_errors test_errors]);
%legend('Training Error','Testing Error');
plot(lambdas,train_errors','b');
hold on;
plot(lambdas,test_errors','g');
title('Ridge Regression');
hold off;
legend('Training Error','Testing Error');
xlabel('lambda');
size(test_errors)

test_errors_ridge=test_errors;
train_errors_ridge=train_errors;
%%%%%%%%%%%%%%%test code

% figure;
% x=1:size(y_train,1);
% size(y_train,1)
% size(y_predicted_test)
% scatter(x, y_train);
% hold on;
% plot(x,y_predicted_test);
% hold off;


%%%%%%%%%%%%%%%%%%%%%%%%






locn=find(test_errors==min((min(test_errors))))
lambda_optimal=lambdas(locn)
%pause;
%%% END PROBLEM 2 CODE %%%

%%% BEGIN PROBLEM 3 CODE
% ridge regression using gradient descent - see handouts (lecture 21 p5) or
% http://cs229.stanford.edu/notes/cs229-notes1.pdf (page 11)
initialWeights = zeros(65,1);
% set the maximum number of iteration in conjugate gradient descent
options = optimset('MaxIter',300);

% define the objective function
lambdas = 0:0.00001:0.001;
train_errors = zeros(length(lambdas),1);
test_errors = zeros(length(lambdas),1);

% run ridge regression training with fmincg
for i = 1:length(lambdas)
    lambda=lambdas(i);
    objFunction = @(params)regressionObjVal(params,x_train_i,y_train,lambda);
    w=fmincg(objFunction,initialWeights,options);
    % fill code here for prediction and computing errors
    train_errors(i,1)=(((y_train-(x_train_i*w))')*(y_train-(x_train_i*w)))^(0.5);
    test_errors(i,1)=(((y_test-(x_test_i*w))')*(y_test-(x_test_i*w)))^(0.5);	
end
figure;


% train_err_gd_min=min(train_errors)
% test_err_gd_min=min(test_errors)
% train_err_gd_max=max(train_errors)
% test_err_gd_max=max(test_errors)
% mean_train_error_gd=mean(train_errors)
% mean_test_error_gd=mean(test_errors)

locn=find(test_errors==min((min(test_errors))))
lambda_optimal_gd=lambdas(locn)
% plot([train_errors test_errors]);
% title('ridge regression using gradient descent');
% legend('Training Error','Testing Error');
% pause;

plot(lambdas,train_errors','b');
hold on;
plot(lambdas,test_errors','g');
title('Regression Using Gradient Descent');
hold off;
legend('Training Error','Testing Error');
xlabel('lambda');
%%% END PROBLEM 3 CODE

%%% BEGIN  PROBLEM 4 CODE
% using variable number 3 only


x_train = x_train(:,3);
x_test = x_test(:,3);
train_errors = zeros(7,1);
test_errors = zeros(7,1);





size(x_train,1)




deg=6;

% no regularization
lambda = 0;
for d = 0:6
    
    x_train_n = mapNonLinear(x_train,d);
    x_test_n = mapNonLinear(x_test,d);
    w = learnRidgeRegression(x_train_n,y_train,lambda);
    %w = learnRidgeRegression(x_train,y_train,lambda);
    % fill code here for prediction and computing errors
    train_errors(d+1,1)=(((y_train-(x_train_n*w))')*(y_train-(x_train_n*w)))^(0.5);
    test_errors(d+1,1)=(((y_test-(x_test_n*w))')*(y_test-(x_test_n*w)))^(0.5);

%     train_errors(d,1)=(((y_train-(x_train*w))')*(y_train-(x_train*w)))^(0.5);
%     test_errors(d,1)=(((y_test-(x_test*w))')*(y_test-(x_test*w)))^(0.5);	
%     if(d==deg)
%         figure;
%         plot(x_train_n(:,2),x_train_n*w,'b');
%         hold on;
%         xlabel('x');
%         ylabel('Predicted & Observed values');
%     end
    
end
% scatter(x_train_n(:,2), y_train,'g');

%title('');
% train_err_nl1_min=min(train_errors)
% test_err_nl1_min=min(test_errors)
% train_err_nl1_max=max(train_errors)
% test_err_nl1_max=max(test_errors)
% mean_train_error_nl1=mean(train_errors)
% mean_test_error_nl1=mean(test_errors)
% locn=find(test_errors==min((min(test_errors))))

figure;


plot(0:6,train_errors,'b');
hold on;
plot(0:6,test_errors,'g');
title('Non-Linear Regression without Regularization');
hold off;
legend('Training Error','Testing Error');
xlabel('Degree of polynomial');


% optimal regularization
lambda = lambda_optimal; % from part 2
for d = 0:6
    x_train_n = mapNonLinear(x_train,d);
    x_test_n = mapNonLinear(x_test,d);
    w = learnRidgeRegression(x_train_n,y_train,lambda);
    % fill code here for prediction and computing errors
    train_errors(d+1,1)=(((y_train-(x_train_n*w))')*(y_train-(x_train_n*w)))^(0.5);
    test_errors(d+1,1)=(((y_test-(x_test_n*w))')*(y_test-(x_test_n*w)))^(0.5);
%     if(d==deg)
%         plot(x_train_n(:,2),x_train_n*w,'r');
%         hold off;
%         xlabel('x');
%         ylabel('Predicted & Observed values');
%     end
end



figure;

% plot([train_errors test_errors]);
% title('Non linear regression with regularization');
% legend('Training Error','Testing Error');
% train_err_nl_min=min(train_errors)
% test_err_nl_min=min(test_errors)
% train_err_nl_max=max(train_errors)
% test_err_nl_max=max(test_errors)
% mean_train_error_nl=mean(train_errors)
% mean_test_error_nl=mean(test_errors)

plot(0:6,train_errors','b');
hold on;
plot(0:6,test_errors','g');
title('Non-Linear Regression with Regularization (Optimal lambda)');
hold off;
legend('Training Error','Testing Error');
xlabel('Degree of polynomial');
